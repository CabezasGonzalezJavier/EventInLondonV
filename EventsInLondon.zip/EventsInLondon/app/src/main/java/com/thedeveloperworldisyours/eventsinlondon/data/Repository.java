package com.thedeveloperworldisyours.eventsinlondon.data;

import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.Section;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.thedeveloperworldisyours.eventsinlondon.utils.Constants.URL_BASE;

/**
 * Created by javierg on 19/04/2017.
 */

public class Repository implements DataSource {

    public static final int TIMER_HTTP_OK = 5;

    public OkHttpClient getOkHttpClient() {
        return new OkHttpClient().newBuilder()
                .connectTimeout(TIMER_HTTP_OK, TimeUnit.SECONDS)
                .readTimeout(TIMER_HTTP_OK, TimeUnit.SECONDS)
                .writeTimeout(TIMER_HTTP_OK, TimeUnit.SECONDS)
                .build();
    }

    @Override
    public Retrofit getEvent() {

        return new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(URL_BASE)
                .client(getOkHttpClient())
                .build();
    }

    @Override
    public List<ElementList> addFavorite(List<ElementList> list, int position) {

        List<ElementList> result = new ArrayList<>();
        EventDomain eventDomain = (EventDomain) list.get(position);
        eventDomain.setFavourite(true);

        result.add(0, new Section("Favorites"));
        result.add(1, list.get(position));
        if (list.get(0).isSection()) {
            for (int i = 1; i < list.size(); i++) {
                if (position > i) {
                    result.add(i + 1, list.get(i));
                } else if (position < i) {
                    result.add(i, list.get(i));
                }
            }
        } else {

            //first favorite
            result.add(2, new Section("No Favorites"));
            for (int i = 0; i < list.size(); i++) {
                if (position > i) {
                    result.add(i + 3, list.get(i));
                } else if (position < i) {
                    result.add(i + 2, list.get(i));
                }
            }
        }

        return result;
    }

    @Override
    public List<ElementList> removeFavorite(List<ElementList> list, int position) {
        List<ElementList> result = new ArrayList<>();
        EventDomain eventDomain = (EventDomain) list.get(position);
        eventDomain.setFavourite(false);

        if (countFavorite(list)>0) {
            for (int i = 0; i < list.size(); i++) {
                if (position > i) {
                    result.add(i, list.get(i));
                } else {
                    if (i < list.size()-1) {
                        result.add(i, list.get(i + 1));
                    } else {
                        result.add(i, list.get(position));
                    }
                }
            }
        } else {
            //there is not favorite remove both header
            for (int i = 0; i < list.size()-2; i++) {
                if (i < list.size()-3) {
                    result.add(i, list.get(i + 3));
                } else {
                    result.add(i, list.get(position));
                }
            }
        }
        return result;
    }

    private int countFavorite(List<ElementList> list) {
        int number = 0;
        for (int i = 0; i < list.size(); i++) {
            if (!list.get(i).isSection()) {
                if (((EventDomain) list.get(i)).isFavourite()) {
                    number ++;
                }
            }
        }
        return number;
    }

}