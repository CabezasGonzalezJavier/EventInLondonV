package com.thedeveloperworldisyours.eventsinlondon.domain;

import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by javierg on 04/07/2017.
 */

public class AddToFavorite {

    Repository mRepository;

    public AddToFavorite(Repository mRepository) {
        this.mRepository = mRepository;
    }

    public List<ElementList> addFavorite(List<ElementList> list, int position) {
        return mRepository.addFavorite(list, position);
    }

}
