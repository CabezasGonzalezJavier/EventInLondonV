package com.thedeveloperworldisyours.eventsinlondon.data.mapper;

import com.thedeveloperworldisyours.eventsinlondon.data.entity.Event;
import com.thedeveloperworldisyours.eventsinlondon.data.entity.Example;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by javierg on 04/07/2017.
 */

public class ExampleToElementList {

    public List<ElementList> convertExampleToEvent(Example example) {
        List<EventDomain> result = new ArrayList<>();
        List<Event> list = example.getEmbedded().getEvents();

        for (int i =0; i<list.size(); i++) {
        result.add(new EventDomain(list.get(i).getName(),
                list.get(i).getImages().get(0).getUrl(),
                list.get(i).getEmbedded().getVenues().get(0).getName(),
                list.get(i).getDates().getStart().getLocalDate(),
                list.get(i).getClassifications().get(0).getGenre().getName()));
        }
        return convertEventListToElementList(result);
    }

    public List<ElementList> convertEventListToElementList(List<EventDomain> list) {
        List<ElementList> result = new ArrayList<>();
            ElementList elementList;
        for (int i= 0; i<list.size(); i++) {
            elementList = list.get(i);
            result.add(elementList);
        }
        return result;
    }
}
