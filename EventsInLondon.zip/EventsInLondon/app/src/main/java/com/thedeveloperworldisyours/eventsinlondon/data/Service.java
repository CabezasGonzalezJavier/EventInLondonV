package com.thedeveloperworldisyours.eventsinlondon.data;

import com.thedeveloperworldisyours.eventsinlondon.data.entity.Example;


import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by javierg on 19/04/2017.
 */

public interface Service {

    @GET("events.json")
    Observable<Example> getEventsRx(@Query("apikey") String order);

}

