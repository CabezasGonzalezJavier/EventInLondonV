package com.thedeveloperworldisyours.eventsinlondon.event;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.thedeveloperworldisyours.eventsinlondon.EventsInLondonApplication;
import com.thedeveloperworldisyours.eventsinlondon.R;
import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.BaseSchedulerProvider;

import javax.inject.Inject;

import static com.thedeveloperworldisyours.eventsinlondon.utils.ActivityUtils.addFragmentToActivity;

public class EventActivity extends AppCompatActivity {
    @Inject
    Repository mRepository;

    @Inject
    BaseSchedulerProvider mSchedulerProvider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        initializeDagger();
        initFragment();
    }

    private void initializeDagger() {
        EventsInLondonApplication app = (EventsInLondonApplication) getApplication();
        app.getAppComponent().inject(this);
    }

    private void initFragment () {
        EventFragment themeFragment = (EventFragment) getSupportFragmentManager().
                findFragmentById(R.id.event_activity_contentFrame);
        if (themeFragment == null) {
            themeFragment = themeFragment.newInstance();
            addFragmentToActivity(getSupportFragmentManager(),
                    themeFragment, R.id.event_activity_contentFrame);
        }
        new EventPresenter(mRepository, themeFragment, mSchedulerProvider);

    }
}
