package com.thedeveloperworldisyours.eventsinlondon.data;

import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;

import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by javierg on 19/04/2017.
 */

public interface DataSource {

    Retrofit getEvent();
    List<ElementList> addFavorite(List<ElementList> list, int position);
    List<ElementList> removeFavorite(List<ElementList> list, int position);
}
