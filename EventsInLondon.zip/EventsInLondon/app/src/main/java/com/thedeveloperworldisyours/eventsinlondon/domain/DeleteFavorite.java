package com.thedeveloperworldisyours.eventsinlondon.domain;

import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;

import java.util.List;

/**
 * Created by javierg on 05/07/2017.
 */

public class DeleteFavorite {

    Repository mRepository;

    public DeleteFavorite(Repository mRepository) {
        this.mRepository = mRepository;
    }

    public List<ElementList> deleteFavorite(List<ElementList> list, int position) {
        return mRepository.removeFavorite(list, position);
    }
}
