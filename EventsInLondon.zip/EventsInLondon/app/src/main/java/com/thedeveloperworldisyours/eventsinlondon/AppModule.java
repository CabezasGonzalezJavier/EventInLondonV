package com.thedeveloperworldisyours.eventsinlondon;

import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.BaseSchedulerProvider;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.SchedulerProvider;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by javierg on 04/07/2017.
 */
@Module
public class AppModule {

    EventsInLondonApplication mEventInLondonApplication;

    public AppModule(EventsInLondonApplication eventInLondonApplication) {
        mEventInLondonApplication = eventInLondonApplication;
    }

    @Singleton
    @Provides
    Repository provideRepository() {
        return new Repository();
    }

    @Singleton
    @Provides
    BaseSchedulerProvider provideSchedulerProvider() {
        return new SchedulerProvider();
    }

}
