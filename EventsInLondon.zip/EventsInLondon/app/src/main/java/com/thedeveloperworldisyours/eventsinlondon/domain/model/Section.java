package com.thedeveloperworldisyours.eventsinlondon.domain.model;

/**
 * Created by javierg on 05/07/2017.
 */

public class Section extends ElementList {
    public Section(String name) {
        this.setName(name);
        this.setSection(true);
    }
}
