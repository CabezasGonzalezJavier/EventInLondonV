package com.thedeveloperworldisyours.eventsinlondon.domain;

/**
 * Created by javierg on 04/07/2017.
 */

public class GetEvent {
}
