package com.thedeveloperworldisyours.eventsinlondon.data.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Created by javierg on 04/07/2017.
 */

public class Twitter {

    @SerializedName("handle")
    @Expose
    private String handle;

    public String getHandle() {
        return handle;
    }

    public void setHandle(String handle) {
        this.handle = handle;
    }

}
