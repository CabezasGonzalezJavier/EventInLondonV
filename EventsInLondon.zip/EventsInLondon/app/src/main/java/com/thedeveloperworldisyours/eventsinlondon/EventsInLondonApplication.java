package com.thedeveloperworldisyours.eventsinlondon;

import android.app.Application;

/**
 * Created by javierg on 04/07/2017.
 */

public class EventsInLondonApplication extends Application {

    AppComponent mAppComponent;

    @Override
    public void onCreate() {
        super.onCreate();
        mAppComponent = DaggerAppComponent.builder()
                .appModule(new AppModule(this))
                .build();
    }

    public AppComponent getAppComponent() {
        return mAppComponent;
    }

}
