package com.thedeveloperworldisyours.eventsinlondon;

/**
 * Created by javierg on 19/04/2017.
 */

public interface BasePresenter {

    void subscribe();

    void unSubscribe();

}
