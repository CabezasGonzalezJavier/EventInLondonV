package com.thedeveloperworldisyours.eventsinlondon.utils;

/**
 * Created by javierg on 04/07/2017.
 */

public class Constants {
    public static final String URL_BASE = "https://app.ticketmaster.com/discovery/v2/";
    public static final String KEY = "5ike7MSNlAAvxYKqXhSyNY324bnkkwld";
}
