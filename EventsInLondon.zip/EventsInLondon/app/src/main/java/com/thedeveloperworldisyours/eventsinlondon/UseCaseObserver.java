package com.thedeveloperworldisyours.eventsinlondon;

import io.reactivex.observers.DisposableObserver;

/**
 * Created by javierg on 04/07/2017.
 */

public class UseCaseObserver<T> extends DisposableObserver<T> {

    @Override public void onComplete() {
    }

    @Override public void onError(Throwable e) {
    }

    @Override public void onNext(T t) {
    }
}