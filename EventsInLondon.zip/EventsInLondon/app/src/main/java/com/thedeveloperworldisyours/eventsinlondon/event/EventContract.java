package com.thedeveloperworldisyours.eventsinlondon.event;

import com.thedeveloperworldisyours.eventsinlondon.BasePresenter;
import com.thedeveloperworldisyours.eventsinlondon.BaseView;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;

import java.util.List;

/**
 * Created by javierg on 04/07/2017.
 */

public class EventContract {

    interface Presenter extends BasePresenter {
        void fetch();

        void addFavorite(List<ElementList> list, int position);
        void deleteFavorite(List<ElementList> list, int position);
    }

    public interface View extends BaseView<Presenter> {
        void showEvents(List<ElementList> list);

        void showError();

        void setLoadingIndicator(boolean active);

        void refreshList(List<ElementList> list);

    }
}
