package com.thedeveloperworldisyours.eventsinlondon.event;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.thedeveloperworldisyours.eventsinlondon.R;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class EventFragment extends Fragment implements EventContract.View, EventAdapter.MyClickListener {

    @BindView(R.id.event_fragment_progress)
    ProgressBar mProgressBar;

    @BindView(R.id.event_fragment_retry_button)
    Button mRetry;

    @BindView(R.id.event_fragment_relative_layout)
    RelativeLayout mRelativeLayout;

    @BindView(R.id.event_fragment_recycler_view)
    RecyclerView mRecyclerView;
    List<ElementList> mListEvent;


    private EventContract.Presenter mPresenter;
    EventAdapter mAdapter;
    public EventFragment() {
        // Required empty public constructor
    }

    public static EventFragment newInstance() {
        return new EventFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.event_fragment, container, false);
        ButterKnife.bind(this, view);
        mPresenter.fetch();
        return view;
    }

    @Override
    public void setPresenter(EventContract.Presenter presenter) {
        mPresenter = presenter;
    }

    @Override
    public void showEvents(List<ElementList> list) {
        mListEvent = list;
        mRecyclerView.setHasFixedSize(true);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mAdapter = new EventAdapter(getActivity(), list);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(this);
    }

    @Override
    public void showError() {
        mProgressBar.setVisibility(View.GONE);
        mRetry.setVisibility(View.VISIBLE);
        mRetry.setText(getString(R.string.retry));
    }

    @Override
    public void setLoadingIndicator(boolean active) {
        if (!active) {
            mRetry.setVisibility(View.GONE);
            mProgressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void refreshList(List<ElementList> list) {
        mAdapter.refreshData(list);
    }

    @Override
    public void onPause() {
        super.onPause();
        mPresenter.unSubscribe();
    }


    @Override
    public void onItemClick(int position, boolean addItem) {

        if (addItem) {
            mPresenter.addFavorite(mListEvent, position);
        } else {
            mPresenter.deleteFavorite(mListEvent, position);
        }
    }

    @OnClick(R.id.event_fragment_retry_button)
    public void retry(View view) {
        mProgressBar.setVisibility(View.VISIBLE);
        mRetry.setVisibility(View.GONE);
        mPresenter.fetch();
    }
}
