package com.thedeveloperworldisyours.eventsinlondon.data.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Created by javierg on 04/07/2017.
 */

public class Social {

    @SerializedName("twitter")
    @Expose
    private Twitter twitter;

    public Twitter getTwitter() {
        return twitter;
    }

    public void setTwitter(Twitter twitter) {
        this.twitter = twitter;
    }

}
