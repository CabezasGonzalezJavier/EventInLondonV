package com.thedeveloperworldisyours.eventsinlondon;

/**
 * Created by javierg on 19/04/2017.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);

}
