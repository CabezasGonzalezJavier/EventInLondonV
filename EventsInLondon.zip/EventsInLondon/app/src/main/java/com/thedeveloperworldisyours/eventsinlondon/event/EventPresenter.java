package com.thedeveloperworldisyours.eventsinlondon.event;

import android.support.annotation.NonNull;
import android.util.LruCache;

import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.data.ServiceInteractor;
import com.thedeveloperworldisyours.eventsinlondon.data.entity.Example;
import com.thedeveloperworldisyours.eventsinlondon.data.mapper.ExampleToElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.AddToFavorite;
import com.thedeveloperworldisyours.eventsinlondon.domain.DeleteFavorite;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.BaseSchedulerProvider;


import java.util.List;

import rx.Subscription;
import rx.subscriptions.CompositeSubscription;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by javierg on 04/07/2017.
 */

public class EventPresenter implements EventContract.Presenter {

    private AddToFavorite mAddToFavorite;

    private DeleteFavorite mDeleteFavorite;
    @NonNull
    private Repository mRepository;

    @NonNull
    private EventContract.View mView;

    @NonNull
    private BaseSchedulerProvider mSchedulerProvider;

    @NonNull
    private CompositeSubscription mSubscriptions;


    public EventPresenter(@NonNull Repository repository, @NonNull EventContract.View view, @NonNull BaseSchedulerProvider provider) {
        this.mRepository = checkNotNull(repository, "repository cannot be null");
        this.mView = checkNotNull(view, "view cannot be null!");
        this.mSchedulerProvider = checkNotNull(provider, "schedulerProvider cannot be null");

        mAddToFavorite = new AddToFavorite(mRepository);
        mDeleteFavorite = new DeleteFavorite(mRepository);
        mSubscriptions = new CompositeSubscription();

        mView.setPresenter(this);
    }

    @Override
    public void fetch() {

        LruCache<String, Example> cache = new LruCache<>(5 * 1024 * 1024); // 5MiB

        final ServiceInteractor interactor = new ServiceInteractor(mRepository.getEvent(), cache);

        Subscription subscription = interactor.getEventFromServer()
                .subscribeOn(mSchedulerProvider.computation())
                .observeOn(mSchedulerProvider.ui())
                .subscribe((Example example) -> {
                            mView.setLoadingIndicator(false);
                            mView.showEvents(new ExampleToElementList().convertExampleToEvent(example));
                        },
                        (Throwable error) -> {
                            try {
                                mView.showError();
                            } catch (Throwable t) {
                                throw new IllegalThreadStateException();
                            }

                        },
                        () -> {
                        });

        mSubscriptions.add(subscription);
    }

    @Override
    public void addFavorite(List<ElementList> list, int position) {
        mView.refreshList(mAddToFavorite.addFavorite(list, position));
    }

    @Override
    public void deleteFavorite(List<ElementList> list, int position) {
        mView.refreshList(mDeleteFavorite.deleteFavorite(list, position));
    }

    @Override
    public void subscribe() {
        fetch();
    }

    @Override
    public void unSubscribe() {
        mSubscriptions.clear();
    }

}
