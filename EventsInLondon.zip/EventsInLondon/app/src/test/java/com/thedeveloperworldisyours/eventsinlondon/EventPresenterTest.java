package com.thedeveloperworldisyours.eventsinlondon;

import com.thedeveloperworldisyours.eventsinlondon.data.Repository;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.ElementList;
import com.thedeveloperworldisyours.eventsinlondon.domain.model.EventDomain;
import com.thedeveloperworldisyours.eventsinlondon.event.EventContract;
import com.thedeveloperworldisyours.eventsinlondon.event.EventPresenter;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.BaseSchedulerProvider;
import com.thedeveloperworldisyours.eventsinlondon.schedulers.ImmediateSchedulerProvider;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;

/**
 * Created by javierg on 05/07/2017.
 */

public class EventPresenterTest {

    @Mock
    private Repository mRepository;

    @Mock
    private EventContract.View mEventView;

    private EventPresenter mPresenter;

    BaseSchedulerProvider mSchedulerProvider;

    @Before
    public void setupTasksPresenter() {
        // Mockito has a very convenient way to inject mocks by using the @Mock annotation. To
        // inject the mocks in the test the initMocks method needs to be called.
        MockitoAnnotations.initMocks(this);

        mPresenter = givenEventPresenter();
    }
    private EventPresenter givenEventPresenter(){
        mSchedulerProvider = new ImmediateSchedulerProvider();
        return new EventPresenter(mRepository, mEventView, mSchedulerProvider);
    }

    @Test
    public void addFavoriteTest() {

        EventDomain eventDomain = new EventDomain("Santana", "image", "venue", "2017.10-21", "rock");
        EventDomain eventDomain2 = new EventDomain("Maria", "image", "venue", "2017.11-10", "rock");
        List<ElementList> list = new ArrayList<>();
        list.add(eventDomain);
        list.add(eventDomain2);
         int position = 1;

        mPresenter.addFavorite(list, position);
        assertTrue(eventDomain2.isFavourite());
        verify(mEventView).refreshList(list);
    }

    @Test
    public void deleteTest() {

        EventDomain eventDomain = new EventDomain("Santana", "image", "venue", "2017.10-21", "rock");
        EventDomain eventDomain2 = new EventDomain("Maria", "image", "venue", "2017.11-10", "rock");
        List<ElementList> list = new ArrayList<>();
        list.add(eventDomain);
        list.add(eventDomain2);
        int position = 1;

        mPresenter.deleteFavorite(list, position);
        assertFalse(eventDomain2.isFavourite());
        verify(mEventView).refreshList(list);
    }
}
